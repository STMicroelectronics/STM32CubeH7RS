  /**
  **********************************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32H7RS devices support on EWARM.
  **********************************************************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *********************************************************************************************************************/

  Package general purpose:
  ======================================================================================================================
	These packages contains the needed files to be installed in order to support STM32H7RS devices by EWARM9 and laters.

	We nform you that this package is suitable for internal & external use.
	EWARMv9_STM32H7RSxx_V1.0.0.exe has been digitally signed by STMicroelectronics.
  
  By running the "Install_Patch.bat" file (as an administrator), the following actions will be performed:
  ======================================================================================================================
	1. If you have previously installed an STM32 patch, it will be removed during the first run. 
	2. The following items will be added :
    - Product line with 64KB Flash size:STM32H7R3x8/H7R7x8/H7S3x8/H7S7x8
    
	- Automatic internal Flash loader selection
    - OSPI loader for STM32H7S78-DK.
	- OSPI loader for STM32H7S78-DK on XSPIM1.
    - OSPI loader for STM32H7S38-NUCLEO. 
	- PSRAM loader for STM32H7S78-DK.
    
   
	3. The following SVD files will be added:
	- STM32H7R and STM32H7S SVD files v1r0.
	

 How to use:
 =======================================================================================================================
 * Before installing the files mentioned above, you need to have EWARM v9.20.1 or later installed. 
 
  You can download EWARM from IAR web site @ www.iar.com
 
 * Run "EWARMv9_STM32H7RSxx_V1.0.0.exe" or using the "Install_Patch.bat" as administrator on EWARM install directory.
   Ewarm Install Directory is "C:\Program Files\IAR Systems\Embedded Workbench \".
   Please change it manually if you have EWARM installed at a different location.   
 
 
 SVD files ReleaseNotes:
 ======================================================================================================================
	=======================================================
	STM32H7R_v1r0: First release
	=======================================================
	Official release.

	=======================================================
	STM32H7S_v1r0: First release
	=======================================================
	Official release.






	




